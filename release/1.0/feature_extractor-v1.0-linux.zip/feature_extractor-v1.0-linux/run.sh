#!/bin/bash
export SWT_GTK3=0;
java -jar feature_extractor-1.0-linux.jar
