#!/bin/bash
export SWT_GTK3=0;
java -XstartOnFirstThread -jar feature_extractor-1.0-osx.jar
